import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Queue;

public class MyAgent extends Agent{
	public static final int UNKNOWN = 4;
	GlobalPercept gp;
	Path mainPath;
	int mainPathGoal;
		
	public MyAgent(int height, int width) {
		gp = new GlobalPercept(height, width);
		mainPath = new Path();
		mainPathGoal = -1;
	}	

	public void act(){
		// add actual percept to global one, and fetch new tiles (those not included in global percept before) 
		HashSet<State> newTiles = gp.updatePercept(percept());
		
		// dirty tile check
		if(gp.net[gp.botR][gp.botC] == DIRTY){
			suck();
			gp.botSucked();
			return;
		}
		
		// planning part
		if(mainPath.isEmpty()){		// I have nothing planned, make a new plan
			Path toNearestDirt = breadthFirst(myState(), DIRTY);
			if(toNearestDirt != null){		// I found a dirty place, I`m going there
				mainPath = toNearestDirt;
				mainPathGoal = DIRTY;
			}
			else{		// there is no dirt in the world I have discovered, can I discover more?
				Path toNearestUnknown = breadthFirst(myState(), UNKNOWN);
				if(toNearestUnknown != null){		// there is a place I haven`t discovered, I`ll go there and take a look
					mainPath = toNearestUnknown;
					mainPathGoal = UNKNOWN;
				}
				else{		// everything is discovered and clean, task complete!
					halt();
				}
			}
		}
		
		else{		// I have something planned, look if I can make better plan with newly percepted tiles			
			if(mainPathGoal == UNKNOWN){		// my previous plan was to discover new area
				if(gp.tileType(mainPath.goal()) != UNKNOWN){		// I already see the tile I was heading to, find some new unexplored area
					Path toGoal = breadthFirst(mainPath.goal(), UNKNOWN);		// new unexplored area will probably be near the place I was heading to, start search from there
					if(toGoal != null){
						mainPath = toGoal;
						mainPathGoal = UNKNOWN;
					}
				}
				if(containsTileType(newTiles, DIRTY)){		// I found some dirt(s), let`s go there to clean it (the nearest one)
					Path toDirt = breadthFirst(myState(), DIRTY);
					if(toDirt != null){
						mainPath = toDirt;
						mainPathGoal = DIRTY;
					}
				}
			}
			else{ 	// my previous plan was to go to dirty place
				if(containsTileType(newTiles, CLEAN)){		// I might have just found a shorter way, let`s check  
					mainPath = aStar(mainPath.goal());
				}
				
				if(containsTileType(newTiles, DIRTY)){		// New dirt might be nearer than the one I was heading to, check it
					mainPath = breadthFirst(myState(), DIRTY);
					mainPathGoal = DIRTY;
				}
			}
		}

		// follow the planned path
		go(mainPath);
	}
	
	public static int heuristic(State s, State goal){
		// Manhattan distance
		return Math.abs(s.c - goal.c) + Math.abs(s.r - goal.r);
	}
	
	private Path aStar(State goal){
		HashSet<State> close = new HashSet<State>();
		Queue<State> open = new PriorityQueue<State>(64, new StateComparator(goal));
		// add starting position
		open.add(new State(gp.botR, gp.botC, getOrientation(), null, 0));
		
		while(!open.isEmpty()){
			State s = open.poll();
			close.add(s);
			// goal check
			if(s.isSamePosition(goal)){
				Path result = new Path();
				result.constructFromFinish(s);
				return result;
			}
			// add successors to open list
			ArrayList<State> succs = successors(s, false);
			for(State succ : succs){
				if(!close.contains(succ)){
					if(!open.contains(succ)){
						open.add(succ);
					}
					else{
						// check if new state has shorter distance from start than already opened equal states
						for(State toCheck : open){
							if(succ.equals(toCheck) && toCheck.distFromStart > succ.distFromStart){
								open.remove(toCheck);
								open.add(succ);
							}
						}
					}
				}
			}
		}
		
		return null;
	}
	
	private Path breadthFirst(State start, int goalType){
		HashSet<State> close = new HashSet<State>();
		Queue<State> open = new ArrayDeque<State>();
		// add starting position
		open.add(start);
		
		while(!open.isEmpty()){
			State s = open.poll();
			if(!close.contains(s)){
				close.add(s);
				// goal check
				if(gp.tileType(s) == goalType){
					Path result = new Path();
					if(goalType == UNKNOWN){
						s = s.prev;
					}
					result.constructFromFinishTo(s, myState());
					return result;
				}
				else{
					// must allow states of type UNKNOWN if searching for UNKNOWN locations
					ArrayList<State> succs = successors(s, goalType == UNKNOWN);
					for(State succ : succs){
						if(!close.contains(succ)){
							open.add(succ);
						}
					}
				}
			}
		}
		
		return null;
	}

	private ArrayList<State> successors(State s, boolean searchForUnknown){
		ArrayList<State> res = new ArrayList<State>();
		// right
		res.add(new State(s.r, s.c, (s.or+1)%4 , s, State.RT));
		// forward
		int succC = s.c, succR = s.r;
		switch(s.or){
			case World.NORTH: succR--; break;
			case World.EAST: succC++; break;
			case World.SOUTH: succR++; break;
			case World.WEST: succC--; break;
		}
		if(	gp.net[succR][succC] != WALL &&
				(searchForUnknown || gp.net[succR][succC] != UNKNOWN))
		{					
			res.add(new State(succR, succC, s.or, s, State.FW));
		}
		// left
		res.add(new State(s.r, s.c, (s.or-1+4)%4 , s, State.LT));
		return res;
	}
	
	private boolean containsTileType(HashSet<State> set, int type){
		for(State s : set){
			if(gp.tileType(s) == type){
				return true;
			}
		}
		return false;
	}
	
	private void go(Path path){
		int action = path.popAction();
		switch(action){
			case State.FW:
				moveFW();
				gp.botMoved(getOrientation());
				break;
			case State.RT: turnRIGHT(); break;
			case State.LT: turnLEFT(); break;
			case -1: halt(); break;
		}
	}
	
	private State myState(){
		// the state of my bot at this moment
		return new State(gp.botR, gp.botC, getOrientation(), null, 0);
	}
	
}