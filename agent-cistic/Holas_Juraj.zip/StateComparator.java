import java.util.Comparator;

public class StateComparator implements Comparator<State> {
	private State goal;

	public StateComparator(State goal){
		this.goal = goal;
	}
	
	@Override
	public int compare(State o1, State o2) {
		int f1 = o1.distFromStart + MyAgent.heuristic(o1, goal);
		int f2 = o2.distFromStart + MyAgent.heuristic(o2, goal);
		return f1 - f2;
	}

}
