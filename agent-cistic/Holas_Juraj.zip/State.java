
public class State{
	int c, r, or, byAction, distFromStart;
	State prev;
	static final int FW = 1, LT = 2, RT = 3;
	
	public State(int r, int c, int or, State prev, int byAction){
		this.c = c;
		this.r = r;
		this.or = or;
		this.prev = prev;
		this.byAction = byAction;
		if(prev == null){
			distFromStart = 0;
		}
		else{
			distFromStart = prev.distFromStart + 1;
		}
	}

	@Override
	public int hashCode() {
		return 	31 * (new Integer(c)).hashCode() ^ 
				41 * (new Integer(r)).hashCode() ^
				73 * (new Integer(or)).hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		try{
			State o = (State) obj;
			return c == o.c && r == o.r && or == o.or;
		}
		catch(ClassCastException e){
			return false;
		}
	}
	
	public boolean isSamePosition(State s){
		return c == s.c && r == s.r;
	}

}