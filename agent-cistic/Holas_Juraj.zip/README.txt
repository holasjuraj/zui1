README Juraj Holas

######## BASIC OUTLINE ########
Agent uses GlobalPercept object to store all information about the world he`ve seen or visited. All coordinates computations
are within global percept coordinates. Agent also have one plan (mainPath) where to go, and he follows this plan. In each step
he check if the plan can be somehow improved, e.g. whether he can found a shorter way to his goal, or better goal to go to.


######## ALGORITHMS ########

#### ACT METHOD ####
Act method is the key decision element for the bot, therefore it`s also quite complicated. It`s basically a series of human-like
decisions (conditions) that determine the plan making. These decisions are shown in diagram below:

                                               Do I already have a plan?
                           __________________________NO___/ \___YES__________________________
                          /                                                                  \
                  Can I find some dirt?                                    What was I looking for (goal type) - dirt or unexplored area?
                 ________NO___/ \___YES________                                   _____________DIRT___/ \___UNKNOWN_______________
                /                              \                                 /                                                \
          Can I find some             Go there to clean it.    With my last percept I might found                With my last percept I might found
          unexplored area?             (goal type = dirt)       some places I didn`t know before.                 some places I didn`t know before.
       ____NO___/ \___YES____                                       Did I just find some ... ?                           Did I just find ... ?
      /                      \                                               / \                                               / \
Everything clear       Go there to explore it.              ___CLEAN_TILE___/   \___DIRT___                         ___DIRT___/   \___MY_GOAL___
and explored, I`m    (goal type = unknown tile)            /                               \                       /                            \
  done. Halt.                                   Maybe it opened a shorter way   Maybe there`s dirt nearer    Go there to         I spotted the unknown tile I was
                                                to the dirt I was heading to.   than the one I was heading    clean it.         going to explore. Find some other
                                                 Check it, and if so, follow    to. Find the nearest dirt.                           unexplored place to go to.
                                                  that shorter way instead.

Except this logic there are also some other features in the act method:
 -> retrieve new percept, and add it to the global percept
 -> check if bot is standing on dirty place, and clean if yes
 -> after creating the plan, calling the go() method will execute one step from the plan

#### A-STAR ####
Standard A* search algorithm was implemented for finding the shortest way to known goal. The algorithm is described in
Exercise 3 info, and the implementation was taken from my own solution of this exercise. Manhattan distance was used as
heuristic function.

#### BREADTH FIRST ####
Standard breadth-first search was also implemented. However, it`s not used for finding a way to known goal. It is only used for
finding the closest goal of certain type, e.g. "find the closest dirty tile". The search is usually started from the bot`s position,
but optionally it can also be started from a different (given) position. The algorithm is described in Exercise 2 info, and
the implementation was taken from my own solution of this exercise.


######## DATA STRUCTURES ########

#### GLOBAL PERCEPT ####
The global percept class holds all the information about all explored world, mainly:
 -> net[][] - array in which the map is stored. Its dimensions are twice as large as the world dimensions, so that no matter
              where the bot is born, the world map will not overflow the net array. (Bot`s initial position is in the middle
              of net array)
 -> botR, botC - bot`s actual position in the net array. It is updated with every bot`s step.
Along the existing CLEAN, DIRTY, WALL and AGENT tile types, a new constant UNKNOWN was declared for representation of the
unexplored areas. Before the first percept whole net array is marked as UNKNOWN.

#### PATH ####
Path is extend to ArrayDeque class, with some extra (mostly simple) functionality:
 -> goal() - if path is non-empty, this function returns the last element. In program logic it means the goal of the path.
 -> constructFromFinish[To]() - constructs the path traversing the linked list of states, starting from the path goal state and
                                finishing in (optionally given) path start state
 -> popAction() - pops the first element, but only return the action that bot should perform
I chose to extend ArrayDeque implementation of Deque and not LinkedList for efficiency reasons (although LinkedList have
O(1) operations, it is slower by factor 2 - 4 due to higher space and pointer maintenance).  

#### STATE ####
State class holds information necessary for executing a search algorithms, but it is also used as a tile reference (coordinates).
It holds following information:
 -> r, c - row and column position of the tile
 -> or - orientation of the bot on the tile
 -> prev - previous state from which we got to this one
 -> byAction - by which action we got from previous state to this one (go forward, turn right or turn left)
 -> distFromStart - how many actions did it take to get from start to this state. Used for comparing the shortest way in
                    A* algorithm.
State class also overrides some methods needed for effective set and queue operations - hashCode(), equals(), and separate derived
Comparator class.