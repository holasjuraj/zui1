import java.util.HashSet;

public class GlobalPercept {
	public int [][] net;
	public int botR;
	public int botC;
	private int totalRows;
	private int totalCols;
	
	public GlobalPercept(int mapRows, int mapCols){
		// global percept net is 2 times larger than map, so that no matter where the bot is born, map will surely fit into net
		totalRows = mapRows*2 + 1;
		totalCols = mapCols*2 + 1;
		botR = mapRows;
		botC = mapCols;
		net = new int[totalRows][totalCols];
		for(int r = 0; r < totalRows; r++){
			for(int c = 0; c < totalCols; c++){
				net[r][c] = MyAgent.UNKNOWN;
			}
		}
	}
	
	public void botMoved(int orientation){
		switch(orientation){
			case World.NORTH: botR--; break;
			case World.EAST: botC++; break;
			case World.SOUTH: botR++; break;
			case World.WEST: botC--; break;
		}
	}
	
	public void botSucked(){
		net[botR][botC] = World.CLEAN;
	}
	
	public HashSet<State> updatePercept(int[][] newPercept){	// returning newly discovered tiles
		HashSet<State> newTiles = new HashSet<State>();
		int perceptSize = newPercept.length / 2;

		for(int newPerR = 0; newPerR < newPercept.length; newPerR++){
			int globPerR = botR - perceptSize + newPerR;
			if(globPerR < 0 || globPerR >= totalRows){ continue; }
			for(int newPerC = 0; newPerC < newPercept[newPerR].length; newPerC++){
				int globPerC = botC - perceptSize + newPerC;
				if(globPerC < 0 || globPerC >= totalCols){ continue; }
				// copy to global only if it was unknown 
				if(net[globPerR][globPerC] == MyAgent.UNKNOWN){
					net[globPerR][globPerC] = newPercept[newPerR][newPerC];
					newTiles.add(new State(globPerR, globPerC, 0, null, 0));
				}
			}
		}
		
		return newTiles;
	}
	
	public int tileType(State s){
		return net[s.r][s.c];
	}

}
