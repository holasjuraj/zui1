import java.util.ArrayDeque;

public class Path extends ArrayDeque<State>{
	public State goal(){
		if(isEmpty()){
			return null;
		}
		else{
			return getLast();
		}
	}
	
	public void constructFromFinish(State s){		// reconstruction of path from given finish state
		clear();
		while(s.prev != null){
			push(s);
			s = s.prev;
		}
	}
	
	public void constructFromFinishTo(State finish, State start){	// reconstruction again, but stops if reaches given startpoint
		clear();
		State s = finish;
		while(s.prev != null && !s.equals(start)){
			push(s);
			s = s.prev;
		}
	}
	
	public int popAction(){
		if(!isEmpty()){
			return pop().byAction;
		}
		return -1;
	}
	
	private static final long serialVersionUID = -6985652228774998974L;
}
