
public interface Present {

	 public void redraw();
}