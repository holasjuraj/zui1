import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Queue;


public class PathFinder {
	private KnowledgeBase kb;
	
	public PathFinder(KnowledgeBase kb){
		this.kb = kb;
	}
	
	public Path killOrExplore(State start){
		HashSet<State> close = new HashSet<State>();
		Queue<State> open = new ArrayDeque<State>();
		// Add starting position
		open.add(start);
		
		while(!open.isEmpty()){
			State s = open.poll();
			if(!close.contains(s)){
				close.add(s);
				// Goal check
				// 1) can I kill Wumpus from here?
				int r = s.r,
					c = s.c;
				switch(s.or){
					case Constants.NORTH:	r--; break;
					case Constants.EAST:	c++; break;
					case Constants.SOUTH:	r++; break;
					case Constants.WEST:	c--; break;
				}
				if(	!kb.ask(new Literal("wumDead", true)) &&
					kb.ask(new ParameterLiteral(r, c, "wum", true))
				){
					Path result = new Path();
					result.constructFromFinish(s);
					result.goalType = MyAgent.GOAL_KILL;
					return result;
				}
				// 2) is this tile unexplored (and safe)?
				if(	!kb.ask(new ParameterLiteral(s.r, s.c, "visited", true)) &&
					kb.ask(new ParameterLiteral(s.r, s.c, "safe", true))
				){
					Path result = new Path();
					result.constructFromFinish(s);
					result.goalType = MyAgent.GOAL_EXPLORE;
					return result;
				}
				
				// Don`t move through non-safe tiles!
				if(!kb.ask(new ParameterLiteral(s.r, s.c, "safe", true))){
					continue;
				}

				// Add successors to open list
				ArrayList<State> succs = successors(s, true);
				for(State succ : succs){
					if(!close.contains(succ)){
						open.add(succ);
					}
				}
				
			}
		}
		
		return null;
	}

	public Path startingPos(State start){
		HashSet<State> close = new HashSet<State>();
		Queue<State> open = new PriorityQueue<State>(128,
				new Comparator<State>() {
					@Override
					public int compare(State o1, State o2) {
						int f1 = o1.distFromStart + heuristic(o1);
						int f2 = o2.distFromStart + heuristic(o2);
						return f1 - f2;
					}
					private int heuristic(State s){
						// Manhattan distance to starting position
						return Math.abs(s.c) + Math.abs(s.r);
					}
				});
		// Add starting position
		open.add(start);
		
		while(!open.isEmpty()){
			State s = open.poll();
			close.add(s);
			// Goal check
			if(s.r==0 && s.c==0){
				Path result = new Path();
				result.constructFromFinish(s);
				result.goalType = MyAgent.GOAL_CLIMB;
				return result;
			}
			
			// Don`t move through non-safe tiles!
			if(!kb.ask(new ParameterLiteral(s.r, s.c, "safe", true))){
				continue;
			}
			
			// Add successors to open list
			ArrayList<State> succs = successors(s, false);
			for(State succ : succs){
				if(!close.contains(succ)){
					if(!open.contains(succ)){
						open.add(succ);
					}
					else{
						// Check if new state has shorter distance from start than already opened equal states
						for(State toCheck : open){
							if(succ.equals(toCheck) && toCheck.distFromStart > succ.distFromStart){
								open.remove(toCheck);
								open.add(succ);
							}
						}
					}
				}
			}
		}
		
		return null;
	}
	
	private ArrayList<State> successors(State s, boolean searchForUnknown){
		ArrayList<State> res = new ArrayList<State>();
		// Right
		res.add(new State(s.r, s.c, (s.or+1) % 4 , s, State.RT));
		
		// Forward
		int succC = s.c, succR = s.r;
		switch(s.or){
			case Constants.NORTH: succR--; break;
			case Constants.EAST: succC++; break;
			case Constants.SOUTH: succR++; break;
			case Constants.WEST: succC--; break;
		}
		boolean isWall = kb.ask(new ParameterLiteral(succR, succC, "wall", true));
		
		if(	(!isWall && kb.ask(new ParameterLiteral(succR, succC, "safe", true)) )	// safe & not wall
			||
			(searchForUnknown && !isWall &&											// I search for unknown:
			 !kb.ask(new ParameterLiteral(succR, succC, "visited", true)) )			// not visited & not wall
		){	
			res.add(new State(succR, succC, s.or, s, State.FW));
		}
		
		// Left
		res.add(new State(s.r, s.c, (s.or-1+4) % 4 , s, State.LT));
		return res;
	}
}
