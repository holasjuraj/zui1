README Juraj Holas

######## BASIC OUTLINE ########
Agent uses knowledge base to store his knowledge, from which he further infers
using standard backward chaining. He regularly creates plan of actions to
execute, which will lead him to the goal. Once he reaches the goal, he executes
the goal action (e.g. kill Wumpus), and make a new plan.


######## ALGORITHMS ########

#### KEY METHODS ####

## createKB() ##
Basic inference rules are added to knowledge base in this method. In some cases
some rules were omitted to simplify the inference process, while preserving its
possibilities. In other cases preconditions were reordered, so that literals,
which are more easier to disprove, are tried first (pruning the more difficult
literals). All inference rules are listed at the end.

## doAction() ##
This method is agent`s key decision element. He follows structure of decisions:
-> if I`m standing at a gold, pick it up
-> if I finished the plan, execute goal action and make a new plan:
   -> find nearest goal, i.e. unvisited tile, or a position from which I can
      kill a Wumpus (prioritized)
   -> if there`s no such goal, find a way back to starting position to climb up
-> follow the plan

## go(path) ##
This method simply pops an action code from the planned path and executes
corresponding action (turn or move forward).

## backwardChaining(literal) ##
Standard FOL backward-chaining algorithm. No optimizations (such as reordering
preconditions or choosing "simpler" rules) were made.

#### FINDING A PATH ####
Two standard algorithms are implemented for finding a path on the map, both are
part of PathFinder class.
-> Breath-first search is used for finding a closest goal (unvisited tile or
   killing position)
-> A-star search is used when everything safe is explored and Wumpus dead (if
   possible) to find a way back to starting position. Manhattan distance is
   used as heuristic function.


######## DATA STRUCTURES - CLASSES ########

#### KNOWLEDGE BASE ####
No changes, except implementation of backward chaining, were made to knowledge
base structure from the assignment. It is still only a set of rules or facts
with the ability to infer new ones.

#### PATH FINDER ####
This class holds all functionality needed for finding a way on the map. The
main part are two finding functions:
-> killOrExplore(): it uses standard breadth-first search algorithm, and check
   the tile against two possible goals: unvisited safe tile, or Wumpus killing
   position (next to it, heading its direction).
-> startingPos(): it uses A* search to find the shortest way back to starting
   position. Manhattan distance to starting position - [0, 0] is used as
   heuristic.

#### PATH ####
Path is extend to ArrayDeque class, with some extra (mostly simple)
functionality:
-> constructFromFinish() - constructs the path traversing the linked list of
   states, starting from the path goal state
-> popAction() - pops the first element, but only return the action that the
   agent should perform
I chose to extend ArrayDeque implementation of Deque and not LinkedList for
efficiency reasons (although LinkedList have O(1) operations, it is slower by
factor 2 - 4 due to higher space and pointer maintenance).  

#### STATE ####
State class holds information necessary for executing a search algorithms.
It holds following information:
-> r, c - row and column position of the tile
-> or - orientation of the agent on the tile
-> prev - previous state from which we got to this one
-> byAction - by which action we got from previous state to this one (go
   forward, turn right or turn left)
-> distFromStart - how many actions did it take to get from start to this
   state. Used for comparing the shortest way in A* algorithm.
State class also overrides some methods needed for effective set and queue
operations - hashCode(), equals(), and derived annonymous Comparator class used
in PathFinder.startingPos() method.


######## KNOWLEDGE BASE ########
As mentioned, some rules were omitted from the knowledge base, as they were
not actually needed. For example, there is no rule that determines where IS a
pit, only where it is NOT.

Used predicate names:
  visited, isStart, shot
  safe,    noSafe
  wum,     noWum,   wumDead
  pit,     noPit
  breeze,  noBreeze
  stench,  noStench
  glitter
  wall

Complete set of inference rules:
  safe(r,c) <- visited(r,c)
  safe(r,c) <- noPit(r,c), noWum(r,c)
  safe(r,c) <- wumDead, noPit(r,c)
  safe(r,c) <- wumDead, wum(r,c)
  safe(r,c) <- stench(r,c)
  safe(r,c) <- breeze(r,c)
  safe(r,c) <- wall(r,c)
  safe(r,c) <- glitter(r,c)

  // Between two stenches is a Wumpus
  wum(r,c) <- stench(r-1,c), stench(r+1,c)
  wum(r,c) <- stench(r,c-1), stench(r,c+1)

  // Two stenches diagonally, no Wumpus next to them -> remaining tile in square is Wumpus
  wum(r,c) <- stench(-1,  0), stench( 0, -1), noWum(-1, -1);
  wum(r,c) <- stench( 1,  0), stench( 0,  1), noWum( 1,  1);
  wum(r,c) <- stench( 1,  0), stench( 0, -1), noWum( 1, -1);
  wum(r,c) <- stench(-1,  0,) stench( 0,  1), noWum(-1,  1);

  // If a stench has 3 safe (noWum) neighbors, the last one is Wumpus
  wum(r,c) <- stench( 1,  0), noWum( 1,  1), noWum( 1, -1), noWum( 2,  0);
  wum(r,c) <- stench(-1,  0), noWum(-1,  1), noWum(-1, -1), noWum(-2,  0);
  wum(r,c) <- stench( 0,  1), noWum( 1,  1), noWum(-1,  1), noWum( 0,  2);
  wum(r,c) <- stench( 0, -1), noWum( 1, -1), noWum(-1, -1), noWum( 0, -2);

  // If there`s no stench next to a tile, that tile is not a Wumpus
  noWum(r,c) <- noStench( 1,  0);
  noWum(r,c) <- noStench(-1,  0);
  noWum(r,c) <- noStench( 0,  1);
  noWum(r,c) <- noStench( 0, -1);

  // If there`s no breeze next to a tile, that tile is not a pit
  noPit(r,c) <- noBreeze( 1,  0);
  noPit(r,c) <- noBreeze(-1,  0);
  noPit(r,c) <- noBreeze( 0,  1);
  noPit(r,c) <- noBreeze( 0, -1);