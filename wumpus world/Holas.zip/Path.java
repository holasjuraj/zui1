import java.util.ArrayDeque;

public class Path extends ArrayDeque<State>{
	
	public int goalType = -1;
	
	public void constructFromFinish(State s){		// Reconstruction of path from given finish state
		clear();
		while(s.prev != null){
			push(s);
			s = s.prev;
		}
	}
	
	public int popAction(){
		if(!isEmpty()){
			return pop().byAction;
		}
		return -1;
	}
	
	private static final long serialVersionUID = -6985652228774998974L;
}
