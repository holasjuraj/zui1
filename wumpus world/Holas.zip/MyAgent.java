import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class MyAgent extends Agent{
    
    //-------------My literal names---------------------
    // visited,	isStart
    // safe,	noSafe
    // wum,		noWum,		wumDead
    // pit,		noPit
    // breeze,	noBreeze
    // stench,	noStench
    // glitter
    // wall
    // shot
    
    //-------------Plan goal types----------------------
	public static final int GOAL_EXPLORE = 0;
	public static final int GOAL_CLIMB = 1;
	public static final int GOAL_KILL = 2;
	
	private boolean[] percept = new boolean[5];
	private int r, c, orientation;
	private KnowledgeBase kb;
	private PathFinder finder;
	private Path plan = new Path();
	private int goalType = -1;
		
	public MyAgent(int orientation, int w, int h) {
		super(orientation);			
		createKB();
		finder = new PathFinder(kb);
	}
	
	private void createKB() {
		HashSet<Formula> a = new HashSet<Formula>();
		
		//=====================================================================
		//                          SAFE TILES 
		//=====================================================================	
		
		// safe(r,c) <- visited(r,c)
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "visited", true)));
		// safe(r,c) <- noPit(r,c), noWum(r,c)
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "noPit", true),
				new MatchingLiteral(0, 0, "noWum", true)));
		// safe(r,c) <- wumDead, noPit(r,c)
		a.add(new Implication(new ParameterLiteral("safe", true),
				new Literal("wumDead", true),
				new MatchingLiteral(0, 0, "noPit", true)));
		// If Wumpus is dead, his tile is safe
		// safe(r,c) <- wumDead, wum(r,c)
		a.add(new Implication(new ParameterLiteral("safe", true),
				new Literal("wumDead", true),
				new MatchingLiteral(0, 0, "wum", true)));

		// safe(r,c) <- [stench/breeze/wall/glitter](r,c)
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "stench", true)));
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "breeze", true)));
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "wall", true)));
		a.add(new Implication(new ParameterLiteral("safe", true),
				new MatchingLiteral(0, 0, "glitter", true)));
		
		//=====================================================================
		//                          WHERE IS WUMPUS?
		//=====================================================================	
		
		// Between two stenches is a Wumpus
		// wum(r,c) <- stench(r-1,c), stench(r+1,c);  wum(r,c) <- stench(r,c-1), stench(r,c+1)
		a.add(new Implication(new ParameterLiteral("wum", true),
				new MatchingLiteral(-1, 0, "stench", true),
				new MatchingLiteral( 1, 0, "stench", true)));
		a.add(new Implication(new ParameterLiteral("wum", true),
				new MatchingLiteral(0, -1, "stench", true),
				new MatchingLiteral(0,  1, "stench", true)));
		
		// Two stenches diagonally, no Wumpus next to them -> remaining tile in square is Wumpus
		// bottom-right tile
		a.add(new Implication(new ParameterLiteral("wum", true),	// .s
				new MatchingLiteral(-1,  0, "stench", true),		// sW
				new MatchingLiteral( 0, -1, "stench", true),
				new MatchingLiteral(-1, -1, "noWum", true)));
		// top-left tile
		a.add(new Implication(new ParameterLiteral("wum", true),	// Ws
				new MatchingLiteral( 1,  0, "stench", true),		// s.
				new MatchingLiteral( 0,  1, "stench", true),
				new MatchingLiteral( 1,  1, "noWum", true)));
		// top-right tile
		a.add(new Implication(new ParameterLiteral("wum", true),	// sW
				new MatchingLiteral( 1,  0, "stench", true),		// .s
				new MatchingLiteral( 0, -1, "stench", true),
				new MatchingLiteral( 1, -1, "noWum", true)));
		// bottom-left tile
		a.add(new Implication(new ParameterLiteral("wum", true),	// s.
				new MatchingLiteral(-1,  0, "stench", true),		// Ws
				new MatchingLiteral( 0,  1, "stench", true),
				new MatchingLiteral(-1,  1, "noWum", true)));
		
		// If a stench has 3 safe (noWum) neighbors, the last one is Wumpus
		// Wumpus is up
		a.add(new Implication(new ParameterLiteral("wum", true),	//  W 
				new MatchingLiteral( 1,  0, "stench", true),		// .s.
				new MatchingLiteral( 1,  1, "noWum", true),			//  . 
				new MatchingLiteral( 1, -1, "noWum", true),
				new MatchingLiteral( 2,  0, "noWum", true)));
		// Wumpus is down
		a.add(new Implication(new ParameterLiteral("wum", true),	//  . 
				new MatchingLiteral(-1,  0, "stench", true),		// .s.
				new MatchingLiteral(-1,  1, "noWum", true),			//  W 
				new MatchingLiteral(-1, -1, "noWum", true),
				new MatchingLiteral(-2,  0, "noWum", true)));
		// Wumpus is left
		a.add(new Implication(new ParameterLiteral("wum", true),	//  . 
				new MatchingLiteral( 0,  1, "stench", true),		// Ws.
				new MatchingLiteral( 1,  1, "noWum", true),			//  . 
				new MatchingLiteral(-1,  1, "noWum", true),
				new MatchingLiteral( 0,  2, "noWum", true)));
		// Wumpus is right
		a.add(new Implication(new ParameterLiteral("wum", true),	//  . 
				new MatchingLiteral( 0, -1, "stench", true),		// .sW
				new MatchingLiteral( 1, -1, "noWum", true),			//  . 
				new MatchingLiteral(-1, -1, "noWum", true),
				new MatchingLiteral( 0, -2, "noWum", true)));
		
		// If there`s no stench next to a tile, that tile is not a Wumpus
		// noWum(r,c) <- noStench(r+-1, c+-1)
		a.add(new Implication(new ParameterLiteral("noWum", true),
				new MatchingLiteral( 1,  0, "noStench", true)));
		a.add(new Implication(new ParameterLiteral("noWum", true),
				new MatchingLiteral(-1,  0, "noStench", true)));
		a.add(new Implication(new ParameterLiteral("noWum", true),
				new MatchingLiteral( 0,  1, "noStench", true)));
		a.add(new Implication(new ParameterLiteral("noWum", true),
				new MatchingLiteral( 0, -1, "noStench", true)));
		
		//=====================================================================
		//                          WHERE IS PIT?
		//         (actually, I only need to know where is NOT a pit)
		//=====================================================================	

		// If there`s no breeze next to a tile, that tile is not a pit
		// noPit(r,c) <- noBreeze(r+-1, c+-1)
		a.add(new Implication(new ParameterLiteral("noPit", true),
				new MatchingLiteral( 1,  0, "noBreeze", true)));
		a.add(new Implication(new ParameterLiteral("noPit", true),
				new MatchingLiteral(-1,  0, "noBreeze", true)));
		a.add(new Implication(new ParameterLiteral("noPit", true),
				new MatchingLiteral( 0,  1, "noBreeze", true)));
		a.add(new Implication(new ParameterLiteral("noPit", true),
				new MatchingLiteral( 0, -1, "noBreeze", true)));

		kb = new KnowledgeBase(a);
	}

	public void act() {
		percept = getPercept();
		writePercept();
		doAction();
	}
			
	private void writePercept(){
		ArrayList<Formula> a = new ArrayList<Formula>();

		a.add(new ParameterLiteral(r, c, "visited", true));
		
		if (percept[Constants.BUMP]){
			a.add(new ParameterLiteral(r, c, "wall", true));
			// Fix wrong positioning (to prevent agent thinking he`s on the wall tile)
			botMoved(-1);
		}
		
		if (percept[Constants.BREEZE]){
			a.add(new ParameterLiteral(r, c, "breeze", true)); }
		else{
			a.add(new ParameterLiteral(r, c, "noBreeze", true)); }
		
		if (percept[Constants.STENCH]){
			a.add(new ParameterLiteral(r, c, "stench", true)); }
		else{
			a.add(new ParameterLiteral(r, c, "noStench", true)); }
		
		if (percept[Constants.GLITTER]){
			a.add(new ParameterLiteral(r, c, "glitter", true)); }
		
		if (percept[Constants.SCREAM]){
			a.add(new Literal("wumDead", true));
		}
											
		kb.tell(a);		
	}

	private int skipInputs = 0;
	private void doAction() {
		// DEBUG : Console commands to the agent:
		//			"" -> go 1 step
		//			"go[enter]N" -> go N steps
		//			"ask[enter]x y name" -> ask knowledge base some parameter literal
		//			"askL[enter]name" -> ask knowledge base some normal literal
		Scanner in = new Scanner(System.in);
		String line = "";
		// if(0 > --skipInputs){ line = in.nextLine(); } // DEBUG : Uncomment to use console commands
		while(!line.equals("")){
			if(line.startsWith("ask")){
				int inputR = in.nextInt(), inputC = in.nextInt();
				String question = in.next();
				System.out.println(kb.ask(new ParameterLiteral(inputR, inputC, question, true)));
			}
			else if(line.startsWith("askL")){
				String question = in.next();
				System.out.println(kb.ask(new Literal(question, true)));
			}
			else if(line.startsWith("go")){
				skipInputs = in.nextInt();
				break;
			}
			line = in.nextLine();
			line = in.nextLine();
		}
		in.close();
		// /DEBUG
		
		// Grab gold
		if (percept[Constants.GLITTER] && !kb.ask(new ParameterLiteral(c, r, "goldGrabbed", true))){
			kb.tell(new ParameterLiteral(c, r, "goldGrabbed", true));
			pickUp();
			return;
		}
		
		// Planning
		if(plan.isEmpty()){
			// If I came to planned location for some action, execute that action
			switch(goalType){
				case GOAL_CLIMB:
					climb();
					return;
				case GOAL_KILL:
					// Shoot only if you haven`t already
					if(!kb.ask(new Literal("shot", true))){
						kb.tell(new Literal("shot", true));
						shoot();
						return;
					}
			}
			
			// Find either unvisited tile, or a position from wich I can kill Wumpus
			plan = findKillOrExplore();
			
			// Nothing more to do here, find a way back to start
			if(plan == null){
				plan = findStartPos();
			}
		}
		
		// Executing plan
		go(plan);
	}
	
	private Path findKillOrExplore(){
		Path result = finder.killOrExplore(myState());
		if(result != null){ goalType = result.goalType; }
		else{ goalType = -1; }
		return result;
	}
	
	private Path findStartPos(){
		Path result = finder.startingPos(myState());
		if(result != null){ goalType = result.goalType; }
		else{ goalType = -1; }
		return result;
	}
	
	private void go(Path path){
		if(path == null || path.isEmpty()){
			// Safety hatch, should never happen
			climb();
			return;
		}
		
		int action = path.popAction();
		switch(action){
			case State.FW:
				moveFW();
				botMoved(1);
				break;
			case State.RT:
				turnRIGHT();
				orientation = (orientation+1) % 4;
				break;
			case State.LT:
				turnLEFT();
				orientation = (orientation-1+4) % 4;
				break;
			default:
				// This should never happen, but one never know
				climb();
		}
	}
	
	private void botMoved(int steps){
		switch(orientation){
			case Constants.NORTH:	r -= steps; break;
			case Constants.EAST:	c += steps; break;
			case Constants.SOUTH:	r += steps; break;
			case Constants.WEST:	c -= steps; break;
		}
	}
	
	private State myState(){
		// The state of agent at this moment
		return new State(r, c, orientation, null, 0);
	}
	
}
