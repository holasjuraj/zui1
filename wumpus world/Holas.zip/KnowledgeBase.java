import java.util.ArrayList;
import java.util.HashSet;

public class KnowledgeBase {
	
	HashSet<Formula> kb;
	
	public KnowledgeBase(HashSet<Formula> kb){
		this.kb = kb;
	}
	
	public boolean remove(Formula f){
		return kb.remove(f);
	}
	
	public void tell(Formula f){
		if (!kb.contains(f)){
			kb.add(f);
		}
	}
	
	public void tell(ArrayList<Formula> f){		
		for (int i = 0; i < f.size(); i++) {
			tell(f.get(i));
		}		
	}
	
	public boolean ask(Literal[] f){
		boolean result = true;
		
		for (int i = 0; i < f.length && result; i++) {
			result = ask(f[i]);
		}
		
		return result;
	}
	
	public boolean ask(Literal f){
		boolean ans = backwardChaining(f);
		return ans;
	}

	private boolean backwardChaining(Literal l) {
		try{
			if(l == null){ return false; }

			// Trivial case - l is fact
			if(kb.contains(l)){
				return true;
			}
			
			// Backward chaining
			for(Formula f : kb){
				if( f.isImplication() && ((Implication)f).match(l) ){
					// l is implied by implication f
					if(ask(((Implication)f).getPreconditions())){
						// showExplanation(l, f);	// DEBUG
						return true;
					}
				}
			}
			
			return false;
		}
		catch(Exception e){
			// If something went terribly wrong
			return false;
		}
	}

	@SuppressWarnings("unused")
	private void showExplanation(Literal l, Formula f) {
		System.out.println("I deduced " + l + " because of\t" + f);		
	}
	
	public String toString(){
		StringBuilder result = new StringBuilder("==============  KB  ==============\n");
		for (Formula a : kb) {
			result.append(a.toString() + "\n");
		}
				
		return result.append("============== END OF KB  ==============\n").toString();
	}

}
