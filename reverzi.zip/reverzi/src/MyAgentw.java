//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
//
//public  class MyAgentw extends Agent{
//	
//	static final int BLACK = World.WHITE_PLAYER;
//	static final int WHITE = World.BLACK_PLAYER;
//	private static final Integer[][] value = {
//		{100,  -4,  13,  9,  9,  13,  -4, 100},
//		{-4, -20,  -5,  1,  1,  -5, -20, -4},
//		{13,  -5,   3,  2,  2,   3,  -5, 13},
//		{ 9,   1,   2,  0,  0,   2,   1,  9},
//		{ 9,   1,   2,  0,  0,   2,   1,  9},
//		{13,  -5,   3,  2,  2,   3,  -5, 13},
//		{-4, -20,  -5,  1,  1,  -5, -20, -4},
//		{100,  -4,  13,  9,  9,  13,  -4, 100}
//	};
//	private static final int[]
//			shiftX = {-1, -1, 0, 1, 1,  1,  0, -1},
//			shiftY = { 0,  1, 1, 1, 0, -1, -1, -1},
//			cornersX = {0, 0, 7, 7},
//			cornersY = {0, 7, 0, 7};
//	private static final int[][]
//			cornerAdjX = {	{0, 1, 1},
//							{0, 1, 1},
//							{6, 6, 7},
//							{6, 6, 7}},
//			cornerAdjY = {	{1, 1, 0},
//							{6, 6, 7},
//							{0, 1, 1},
//							{7, 6, 6}};
//	
//	private long deadline = 0;
//	private boolean fullTree = true;
//	
//	public MyAgentw(World world){
//		super(world);
//	}
//
//	@Override	
//	public int act(int plocha[][], int[] tahy, int timeLimit){
//		deadline = System.currentTimeMillis() + (long)((double)timeLimit * 0.99) - 6;
//		int bestScore = Integer.MIN_VALUE,
//			bestMove = 0;
//		for(int iteration = 1;; iteration++){	
//			fullTree = true;
//			int[] subResult = alphaBeta(plocha, iteration, Integer.MIN_VALUE, Integer.MAX_VALUE, BLACK);
//			int score = subResult[0],
//				almostDead = subResult[1],
//				move = subResult[2];
//			
//			if(almostDead == 1){
//				if(score > bestScore){
//					bestMove = move;
//				}
////				System.out.println("Reached time limit, iterations: "+iteration);
//				break;
//			}
//			else if(fullTree){
////				System.out.println("Searched whole tree, iterations: "+iteration);
//				bestMove = move;
//			}
//			else{
//				bestScore = score;
//				bestMove = move;
//			}
//		}
//		
//		for(int i = 0; i < tahy.length; i++){
//			if(tahy[i] == bestMove){
//				return i;
//			}
//		}
//		return 0;
//	}
//
//	private static class MyListComparator implements Comparator<Integer>{
//		@Override
//		public int compare(Integer a, Integer b) {
//			return -value[a / 10][a % 10].compareTo(value[b / 10][b % 10]);
//		}
//	}
//	private MyListComparator listComp = new MyListComparator();
//	private int[] alphaBeta(int[][] state, int depth, int alpha, int beta, int player){
//		if(System.currentTimeMillis() >= deadline){	// PANIC! Time limit has almost exceeded, quickly get out f the computation tree!
//			return new int[]{Integer.MIN_VALUE, 1, 0};
//		}
//		
//		int[] moves = world.getPossibleMoves(state, player);
//		
//		if(moves.length == 0){	// terminal state
//			return new int[]{heuristicTerminal(state), 0, 0};
//		}
//		if(depth == 0){
//			fullTree = false;
////			return new int[]{heuristicTerminal(state), 0, 0};
//			return new int[]{heuristic2(state, player, moves.length), 0, 0};
//		}
//		
//		int result = 0,
//			almostDead = 0,
//			selectedMove = 0;
//		ArrayList<Integer> movesList = new ArrayList<>(moves.length);
//		for(int move : moves){ movesList.add(move); }
//		Collections.sort(movesList, listComp);
//		
//		for(Integer move : movesList){
//			int[][] successor = world.getResultingState(state, move, player);
//			int[] subResult = alphaBeta(successor, depth-1, alpha, beta, other(player));
//			int abValue = subResult[0];
//			almostDead = subResult[1];
//			
//			if(player == BLACK){
//				if(abValue > alpha){
//					alpha = abValue;
//					selectedMove = move;
//					result = alpha;
//				}
//			}
//			else{
//				if(abValue < beta){
//					beta = abValue;
//					selectedMove = move;
//					result = beta;
//				}
//			}
//			if(almostDead == 1 || beta <= alpha){
//				break;
//			}
//		}
//		return new int[]{result, almostDead, selectedMove};
//	}
//	
//	private int heuristic(int[][] state, int player, int myMovesCount){
//		int totalValue = 0;
//		for(int i = 0; i < state.length; i++){
//			for(int j = 0; j < state[i].length; j++){
//				if(state[i][j] == player){
//					totalValue += value[i][j];
//				}
//				else if(state[i][j] == other(player)){
//					totalValue -= value[i][j];
//				}
//			}
//		}
//		
//		int opMovesCount = world.getPossibleMoves(state, other(player)).length;
//		
//		int result = totalValue + 50*(myMovesCount - opMovesCount);
//		
//		return (player == BLACK) ? result : -result ;
//	}
//
//	private int heuristic2(int[][] state, int player, int myMovesCount){
//		double	countHeur = 0,
//				frontierHeur = 0,
//				cornerHeur = 0,
//				cornerAdjHeur = 0,
//				mobilityHeur = 0;
//
//	// Piece difference, frontier disks and disk squares
//		int myCount = 0,
//			opCount = 0,
//			myFrontiers = 0,
//			opFrontiers = 0,
//			totalValue = 0;
//		for(int i = 0; i < 8; i++){
//			for(int j = 0; j < 8; j++){
//				if(state[i][j] == player){
//					myCount++;
//					totalValue += value[i][j];
//				}
//				else if(state[i][j] == other(player)){
//					opCount++;
//					totalValue -= value[i][j];
//				}
//
//				if(state[i][j] != 0){
//					for(int d = 0; d < 8; d++)  {
//						int ii = i + shiftX[d],
//							jj = j + shiftY[d];
//						if(world.isOkCoord(ii, jj) && state[ii][jj] == 0) {
//							if(state[i][j] == player){ myFrontiers++; }
//							else{ opFrontiers++; }
//							break;
//						}
//					}
//				}
//			}
//		}
//
//		if(myCount > opCount){ countHeur = (100.0 * myCount)/(myCount + opCount); } else
//		if(myCount < opCount){ countHeur = -(100.0 * opCount)/(myCount + opCount); }
//
//		if(myFrontiers > opFrontiers){ frontierHeur = -(100.0 * myFrontiers)/(myFrontiers + opFrontiers); } else
//		if(myFrontiers < opFrontiers){ frontierHeur = (100.0 * opFrontiers)/(myFrontiers + opFrontiers); }
//
//	// Corner occupancy
//		int myCorners = 0,
//			opCorners = 0,
//			myCornerAdj = 0,
//			opCornerAdj = 0;
//		for(int c = 0; c < 4; c++){
//			int cornerVal = state[cornersX[c]][cornersY[c]];
//			if(cornerVal == player){ myCorners++; }
//			else if(cornerVal == other(player)){ opCorners++; }
//			else{
//				for(int a = 0; a < 3; a++){
//					int cornerAdjVal = state[cornerAdjX[c][a]][cornerAdjY[c][a]];
//					if(cornerAdjVal == player){ myCornerAdj++; } else
//					if(cornerAdjVal == other(player)){ opCornerAdj++; }
//				}
//				break;
//			}		
//		}
//
//		cornerHeur = 25 * (myCorners - opCorners);
//		cornerAdjHeur = -12.5 * (myCornerAdj - opCornerAdj);
//
//	// Mobility
//		int opMovesCount = world.getPossibleMoves(state, other(player)).length;
//		if(myMovesCount > opMovesCount){ mobilityHeur = (100.0 * myMovesCount)/(myMovesCount + opMovesCount); } else
//		if(myMovesCount < opMovesCount){ mobilityHeur = -(100.0 * opMovesCount)/(myMovesCount + opMovesCount); }
//
//	// final weighted score
//		return (int)(10 * countHeur +
//					74.396 * frontierHeur +
//					10 * totalValue +
//					801.724 * cornerHeur +
//					382.026 * cornerAdjHeur +
//					78.922 * mobilityHeur);
//	}
//	
//	private int heuristicTerminal(int[][] state){
//		int result = 0;
//		for(int i = 0; i < state.length; i++){
//			for(int j = 0; j < state[i].length; j++){
//				if(state[i][j] == BLACK){ result++; }
//				else if(state[i][j] == WHITE){ result--; }
//			}
//		}
//		return result;
//	}
//	
//	private static int other(int player){
//		return (player == BLACK) ? WHITE : BLACK;
//	}
//}





import java.util.Random;

public  class MyAgentw extends Agent{
	
	Random rnd = new Random();
	
	public MyAgentw(World world){
		super(world);		
	}
		
	public int act(int plocha[][], int[] tahy, int timeLimit){
//		return rnd.nextInt(tahy.length);
		return 0;
//		return tahy.length -1;
	}	
}