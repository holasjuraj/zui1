README Juraj Holas

######## BASIC OUTLINE ########
Agent uses Mini-Max algorithm with Alpha-Beta pruning. Depth of Mini-Max search
tree is iteratively increased while we still have time (iterative deepening).
Depending on state type, agent uses two type of heuristics - one for leaves
(terminal states) and other for non-leaves (mid-game states).

######## USED HEURISTICS ########
As mentioned, two heuristic functions are used:
1) Mid-game heuristic
  In the beginning and middle parts of the game, I use combination of two
  aspects to evaluate the heuristic of a state:
  i) Value of my minus opponent's stones:
    The value of stones is pre-computed (and slightly modified based on
    empirical testing) in the "value" array.
  ii) Number of my minus opponent's possible moves:
    Number of my moves is passed to the function, so that it doesn't have to
    compute it again. Number of opponent's moves is estimated as number of moves
    that opponent could do if it was his turn.
  As the former aspect gives significantly higher values than the latter one, I
  weight the latter by factor of 50.
2) Terminal heuristic
  Once we are able to reach the terminal state of the game in the computation
  tree, it's useful to change the heuristic, because at the end of the game
  even stones with negative value come handy. Therefore, if the state is
  terminal, the heuristic changes to simple difference between my and
  opponent's number of stones, regardless of their value.
I tried also other, more sophisticated heuristics including potential mobility
calculation "X-stones" and "C-stones" detection and much more. However,
empirical tests showed that due to higher time consumption it was
counter-effective to use these heuristics, as they left fewer time for
deepening the search tree. Therefore I decided to leave the final algorithm
only with this simple (mid-game) heuristic.


######## TIMING OPTIMIZATIONS ########
A strategy based on iterative deepening is implemented in order to maximize the
amount of used time within the time limit. Search is iterated several times
while increasing the maximal depth of a search tree, and when the time limit is
almost reached, search is aborted and the best found value is returned.
-> Using of search tree time limit
  At the very beginning of the algorithm I set a deadline for the search tree.
  It considers the time needed to return from a tree depending on its depth
  (estimated as 1% of total time limit) plus some constant to ensure finishing
  the rest of act() method within actual time limit.
-> Detecting deadline and leaving the tree
  Deadline detection comes as a first thing in the aplhabeta() method. If the
  current time reached the deadline, the algorithm starts to "panic" and ends
  anything it is currently doing. The alphabeta() method immediately returns
  a dummy negative value along with the "almostDead" flag. When the parent
  alphabeta() method receives a result with "almostDead" flag, it doesn't
  continue with the algorithm and returns so far best found value, again with
  the "almostDead" flag. This way the flag goes up the recursion stack and
  terminates all calls of recursion, returning the value as soon as possible.
-> Full tree detection
  As the tree has finite depth, near the end of the game we are able to search
  it completely. If we do this in a particular iteration of iterative deepening
  there's no reason to run next iteration with increased maximal depth, as the
  result would be the same. Therefore, if I detect that whole tree was
  searched, I break the iterative deepening and return obtained value.
-> Moves ordering
  To maximize the possibility of trying the pruning option sooner, I reorder
  the possible moves. After reordering the moves that place a stone on a better
  position (with higher value) comes first, as they might increase the overall
  stones value, therefore increasing the result of heuristic, therefore
  increasing the chance of alpha-beta pruning, therefore leaving more time for
  the rest of the search tree.