import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public  class MyAgentb extends Agent{
	
	static final int BLACK = World.BLACK_PLAYER;
	static final int WHITE = World.WHITE_PLAYER;
	// values of all positions
	private static final Integer[][] value = {
		{100,  -4, 13, 9, 9, 13,  -4, 100},
		{ -4, -20, -5, 1, 1, -5, -20,  -4},
		{ 13,  -5,  3, 2, 2,  3,  -5,  13},
		{  9,   1,  2, 0, 0,  2,   1,   9},
		{  9,   1,  2, 0, 0,  2,   1,   9},
		{ 13,  -5,  3, 2, 2,  3,  -5,  13},
		{ -4, -20, -5, 1, 1, -5, -20,  -4},
		{100,  -4, 13, 9, 9, 13,  -4, 100}
	};
	
	private long deadline = 0;
	private boolean fullTree = true;
	
	public MyAgentb(World world){
		super(world);
	}

	@Override	
	public int act(int plocha[][], int[] tahy, int timeLimit){
		// set the deadline for computation tree, leave some space for returning values from the tree
		deadline = System.currentTimeMillis() + (long)((double)timeLimit * 0.99) - 6;
		
		int bestScore = Integer.MIN_VALUE,
			bestMove = 0;
		// iterative deepening - start with depth=1 and increase depth while there`s still some time
		for(int iteration = 1;; iteration++){	
			fullTree = true;
			int[] result = alphaBeta(plocha, iteration, Integer.MIN_VALUE, Integer.MAX_VALUE, BLACK);
			int score = result[0],
				almostDead = result[1],
				move = result[2];
			
			if(almostDead == 1){	// time`s up, proceed to returning a value
				if(score > bestScore){	// maybe I found a better score in the partial tree I computed
					bestMove = move;
				}
				break;
			}
			else if(fullTree){		// I searched whole tree, no need to increase depth, proceed to returning a value
				bestMove = move;
				break;
			}
			else{					// save result from this iteration, continue with next one
				bestScore = score;
				bestMove = move;
			}
		}
		
		// I found the code of my desired move, I have to find it in the array and return its index
		for(int i = 0; i < tahy.length; i++){
			if(tahy[i] == bestMove){
				return i;
			}
		}
		
		// this should never happen, but must be here for proper compilation 
		return 0;
	}

	// comparator to sort moves according to value of the new stone (descending)
	private static class MyListComparator implements Comparator<Integer>{
		@Override
		public int compare(Integer a, Integer b) {
			return - value[a / 10][a % 10].compareTo(value[b / 10][b % 10]);
		}
	}
	private MyListComparator listComp = new MyListComparator();
	
	private int[] alphaBeta(int[][] state, int depth, int alpha, int beta, int player){
		if(System.currentTimeMillis() >= deadline){	// PANIC! Time limit has almost exceeded, quickly get out of the computation tree!
			return new int[]{Integer.MIN_VALUE, 1, 0};
		}
		
		int[] moves = world.getPossibleMoves(state, player);	// quite time-consuming, better compute only once and then pass the result
		
		if(moves.length == 0){	// terminal state - compute terminal heuristic
			return new int[]{heuristicTerminal(state), 0, 0};
		}
		if(depth == 0){			// reached the maximal depth - compute normal heuristic
			fullTree = false;
			return new int[]{heuristic(state, player, moves.length), 0, 0};
		}
		
		// initialize returning variables
		int result = 0,
			almostDead = 0,
			selectedMove = 0;
		
		// sort moves to evaluate according to their estimated profit (value of the new stone)
		ArrayList<Integer> movesList = new ArrayList<>(moves.length);
		for(int move : moves){ movesList.add(move); }
		Collections.sort(movesList, listComp);
		
		// try all moves
		for(Integer move : movesList){
			int[][] successor = world.getResultingState(state, move, player);
			int[] subResult = alphaBeta(successor, depth-1, alpha, beta, other(player));
			int abValue = subResult[0];
			almostDead = subResult[1];
			
			// alpha or beta computation
			if(player == BLACK){
				if(abValue > alpha){
					alpha = abValue;
					selectedMove = move;
					result = alpha;
				}
			}
			else{
				if(abValue < beta){
					beta = abValue;
					selectedMove = move;
					result = beta;
				}
			}
			
			// alpha/beta cutoff or no-time-left cutoff
			if(almostDead == 1 || beta <= alpha){
				break;
			}
		}
		return new int[]{result, almostDead, selectedMove};
	}
	
	// heuristic calculates value of my vs. opponent`s stones and my vs. opponent`s mobility
	private int heuristic(int[][] state, int player, int myMovesCount){
		int totalValue = 0;
		for(int i = 0; i < state.length; i++){
			for(int j = 0; j < state[i].length; j++){
				if(state[i][j] == player){
					totalValue += value[i][j];
				}
				else if(state[i][j] == other(player)){
					totalValue -= value[i][j];
				}
			}
		}
		
		int opMovesCount = world.getPossibleMoves(state, other(player)).length;
		
		int result = totalValue + 50*(myMovesCount - opMovesCount);
		
		return (player == BLACK) ? result : -result ;
	}
	
	// heuristic used for evaluating terminal state of game - when no other moves are possible
	private int heuristicTerminal(int[][] state){
		int result = 0;
		for(int i = 0; i < state.length; i++){
			for(int j = 0; j < state[i].length; j++){
				if(state[i][j] == BLACK){ result++; }
				else if(state[i][j] == WHITE){ result--; }
			}
		}
		return result;
	}
	
	// helper method for swapping players
	private static int other(int player){
		return (player == BLACK) ? WHITE : BLACK;
	}
}